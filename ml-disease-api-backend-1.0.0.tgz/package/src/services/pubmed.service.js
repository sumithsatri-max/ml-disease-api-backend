const axios = require("axios");

const BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils";

function commonParams() {
  const p = {
    tool: process.env.NCBI_TOOL || "ml-disease-detection-app",
    email: process.env.NCBI_EMAIL || "example@example.com"
  };
  if (process.env.NCBI_API_KEY) p.api_key = process.env.NCBI_API_KEY;
  return p;
}

function todayUTC() {
  return new Date().toISOString().slice(0, 10);
}

function isFuturePublicationDate(value) {
  const match = String(value || "").match(/(\d{4})[- ]?(\d{2})?[- ]?(\d{2})?/);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2] || 1);
  const day = Number(match[3] || 1);
  return new Date(Date.UTC(year, month - 1, day)) > new Date(`${todayUTC()}T00:00:00Z`);
}

async function latestStudies(disease, limit = 10) {
  if (!disease || !String(disease).trim()) throw new Error("Disease is required");

  const requestedLimit = Math.min(Math.max(Number(limit) || 10, 1), 50);
  const search = await axios.get(`${BASE_URL}/esearch.fcgi`, {
    params: {
      ...commonParams(),
      db: "pubmed",
      term: `${disease}[Title/Abstract]`,
      sort: "pub date",
      datetype: "pdat",
      maxdate: todayUTC().replace(/-/g, "/"),
      retmax: requestedLimit,
      retmode: "json"
    },
    timeout: 15000
  });

  const ids = search.data?.esearchresult?.idlist || [];
  if (!ids.length) return [];

  const summary = await axios.get(`${BASE_URL}/esummary.fcgi`, {
    params: {
      ...commonParams(),
      db: "pubmed",
      id: ids.join(","),
      retmode: "json"
    },
    timeout: 15000
  });

  const result = summary.data?.result || {};
  return ids.map(id => {
    const r = result[id] || {};
    return {
      pmid: id,
      title: r.title || null,
      journal: r.fulljournalname || r.source || null,
      publicationDate: r.pubdate || null,
      authors: (r.authors || []).map(a => a.name).filter(Boolean),
      articleIds: r.articleids || [],
      source: "PubMed"
    };
  }).filter(study => !isFuturePublicationDate(study.publicationDate));
}

module.exports = { latestStudies };
