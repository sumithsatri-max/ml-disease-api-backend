const axios = require("axios");

const BASE_URL = "https://api.fda.gov/drug/label.json";

function normalize(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[()]/g, " ")
    .replace(/\s+/g, " ");
}

function clean(value) {
  return String(value || "").trim().replace(/\s+/g, " ");
}

function isExactSingleIngredient(requestedName, genericNames = []) {
  const requested = normalize(requestedName);
  if (!requested) return false;

  return genericNames.some((generic) => {
    const value = normalize(generic);

    // Only accept the requested ingredient itself, optionally followed by
    // a common salt form. This intentionally rejects combinations such as
    // "SITAGLIPTIN AND METFORMIN HYDROCHLORIDE" when searching for metformin.
    const allowed = new Set([
      requested,
      `${requested} hydrochloride`,
      `${requested} sodium`,
      `${requested} sulfate`,
      `${requested} fumarate`,
      `${requested} acetate`,
      `${requested} tartrate`,
      `${requested} potassium`,
      `${requested} calcium`
    ]);

    return allowed.has(value);
  });
}

function unique(values = []) {
  return [...new Set(values.map(clean).filter(Boolean))];
}

function mapLabel(label) {
  const openFDA = label.openfda || {};

  return {
    brandNames: unique(openFDA.brand_name),
    genericNames: unique(openFDA.generic_name),
    manufacturer: unique(openFDA.manufacturer_name),
    indications: unique(label.indications_and_usage),
    warnings: unique(label.warnings),
    contraindications: unique(label.contraindications),
    adverseReactions: unique(label.adverse_reactions),
    dosageAndAdministration: unique(label.dosage_and_administration),
    drugInteractions: unique(label.drug_interactions),
    route: unique(openFDA.route),
    source: "openFDA"
  };
}

async function searchDrugLabels(drugName, limit = 20) {
  if (!drugName) throw new Error("Drug name is required");

  const params = {
    search: `openfda.generic_name:"${drugName}"`,
    limit: Math.min(Number(limit) || 20, 100)
  };

  if (process.env.OPENFDA_API_KEY) params.api_key = process.env.OPENFDA_API_KEY;

  const response = await axios.get(BASE_URL, {
    params,
    timeout: 15000
  });

  return (response.data.results || [])
    .filter((label) => isExactSingleIngredient(drugName, label.openfda?.generic_name || []))
    .map(mapLabel);
}

module.exports = { searchDrugLabels };
