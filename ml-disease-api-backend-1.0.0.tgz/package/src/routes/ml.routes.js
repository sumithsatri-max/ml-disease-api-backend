const express = require("express");
const router = express.Router();
const { findDisease } = require("../data/diseases");

/*
  Replace predictDisease() with your real Python/ONNX/TensorFlow/PyTorch
  inference call. The current implementation is intentionally a safe demo.
*/

function predictDisease(input) {
  const text = JSON.stringify(input).toLowerCase();

  if (text.includes("thirst") || text.includes("frequent urination") || text.includes("hba1c")) {
    return { diseaseId: "D001", confidence: 0.80 };
  }
  if (text.includes("blood pressure") || text.includes("hypertension")) {
    return { diseaseId: "D002", confidence: 0.80 };
  }
  if (text.includes("wheezing") || text.includes("asthma")) {
    return { diseaseId: "D003", confidence: 0.80 };
  }
  return { diseaseId: null, confidence: 0 };
}

router.post("/predict", (req, res) => {
  if (!req.body || typeof req.body !== "object" || Array.isArray(req.body) || Object.keys(req.body).length === 0) {
    return res.status(400).json({
      error: "Prediction input is required",
      example: { symptoms: ["thirst", "frequent urination"] }
    });
  }

  const prediction = predictDisease(req.body);
  const disease = prediction.diseaseId ? findDisease(prediction.diseaseId) : null;

  res.json({
    model: {
      type: "demo-rule-based",
      status: "PLACEHOLDER",
      replaceWith: "Python/ONNX/TensorFlow/PyTorch inference service"
    },
    prediction: {
      diseaseId: prediction.diseaseId,
      disease: disease?.name || null,
      confidence: Number(prediction.confidence.toFixed(2))
    },
    nextStep: disease
      ? `/api/diseases/${disease.id}`
      : "No supported disease detected",
    disclaimer: "Demo inference only. A model prediction is not a confirmed diagnosis and should not be used as a medical decision."
  });
});

module.exports = router;
