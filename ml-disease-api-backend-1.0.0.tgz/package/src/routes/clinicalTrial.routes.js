const express = require("express");
const router = express.Router();
const { searchClinicalTrials } = require("../services/clinicalTrials.service");

router.get("/search", async (req, res, next) => {
  try {
    const condition = String(req.query.condition || "").trim();
    if (!condition) {
      return res.status(400).json({ error: "Query parameter 'condition' is required" });
    }

    const data = await searchClinicalTrials(condition, {
      limit: req.query.limit,
      status: req.query.status
    });

    res.json({
      condition,
      ...data
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
