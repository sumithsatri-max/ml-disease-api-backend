const express = require("express");
const router = express.Router();
const { searchDrugLabels } = require("../services/openfda.service");

router.get("/search", async (req, res, next) => {
  try {
    const name = String(req.query.name || "").trim();
    if (!name) return res.status(400).json({ error: "Query parameter 'name' is required" });

    const medications = await searchDrugLabels(name, req.query.limit);

    res.json({
      query: name,
      count: medications.length,
      medications,
      source: "openFDA",
      disclaimer: "Do not use this information to make individual treatment decisions."
    });
  } catch (err) {
    next(err);
  }
});

router.get("/:name", async (req, res, next) => {
  try {
    const medications = await searchDrugLabels(req.params.name, 10);
    res.json({
      query: req.params.name,
      count: medications.length,
      medications,
      source: "openFDA"
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
